using GraphQL.Types;
using OrchardCore.RAQModule.Models;

namespace OrchardCore.RAQModule.GraphQL
{
    public class ButtonPartQueryObjectType : ObjectGraphType<ButtonPart>
    {
        public ButtonPartQueryObjectType()
        {
            Name = "ButtonPart";

            Field(x => x.Text, nullable: true);
            Field(x => x.Type, nullable: true);
        }
    }
}