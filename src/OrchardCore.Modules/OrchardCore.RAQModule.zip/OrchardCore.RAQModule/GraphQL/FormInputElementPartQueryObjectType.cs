using GraphQL.Types;
using OrchardCore.RAQModule.Models;

namespace OrchardCore.RAQModule.GraphQL
{
    public class FormInputElementPartQueryObjectType : ObjectGraphType<FormInputElementPart>
    {
        public FormInputElementPartQueryObjectType()
        {
            Name = "FormInputElementPart";

            Field(x => x.Name, nullable: true);
        }
    }
}