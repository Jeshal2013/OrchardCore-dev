namespace OrchardCore.RAQModule.ViewModels
{
    public class FormElementPartEditViewModel
    {
        public string Id { get; set; }
    }
}
