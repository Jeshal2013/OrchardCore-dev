using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using Castle.Core.Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using OrchardCore.ContentManagement;
using OrchardCore.DisplayManagement;
using OrchardCore.Email;
using OrchardCore.Email.Services;
using OrchardCore.RAQModule.Models;
using OrchardCore.RAQModule.ViewModels;
using OrchardCore.Users.Services;
using MailMessage = OrchardCore.Email.MailMessage;
// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace OrchardCore.RAQModule.Controllers
{
    public class SendRequestController : Controller
    {
        // GET: /<controller>/
        private readonly ISmtpService _smtpService;
        private readonly IStringLocalizer<SendRequestController> S;
        private readonly IUserService _userService;
        public SendRequestController(
          ISmtpService smtpService, IStringLocalizer<SendRequestController> stringLocalizer, IUserService userService)
        {
            S = stringLocalizer;
            _smtpService = smtpService;
            _userService = userService;
        }
        
        [HttpPost,HttpGet]
        public async Task<IActionResult> Index(RaqSendMessageModel model)
        {
            var isSent = false;
            var jsonResponse = new CommonJsonresponse();

            try
            {
                if (ModelState.IsValid)
                {
                    // send email with callback link
                    model.IPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
                    isSent = await this.SendEmailAsync(model.EmailAddress,model.Email, S["Request Quote"], model,model.Cc,model.Bcc);
                }
                if (isSent)
                {
                    jsonResponse.status = 1;
                    jsonResponse.Message = "Email successfully sent";
                }
            }
            catch (Exception ex)
            {
                jsonResponse.Message = ex.Message;
            }
            return Json(jsonResponse);
        }
    }
}
