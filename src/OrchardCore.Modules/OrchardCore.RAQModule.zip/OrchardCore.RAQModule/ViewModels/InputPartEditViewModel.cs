namespace OrchardCore.RAQModule.ViewModels
{
    public class InputPartEditViewModel
    {
        public string Type { get; set; }
        public string DefaultValue { get; set; }
        public string Placeholder { get; set; }
    }
}
