using OrchardCore.ContentManagement;

namespace OrchardCore.RAQModule.Models
{
    public class ButtonPart : ContentPart
    {
        public string Text { get; set; }
        public string Type { get; set; }
    }
}
