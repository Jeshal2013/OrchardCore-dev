namespace OrchardCore.RAQModule.ViewModels
{
    public class FormInputElementPartEditViewModel
    {
        public string Name { get; set; }
    }
}
