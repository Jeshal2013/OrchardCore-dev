using GraphQL.Types;
using OrchardCore.RAQModule.Models;

namespace OrchardCore.RAQModule.GraphQL
{
    public class FormElementPartQueryObjectType : ObjectGraphType<FormElementPart>
    {
        public FormElementPartQueryObjectType()
        {
            Name = "FormElementPart";

            Field(x => x.Id, nullable: true);
        }
    }
}