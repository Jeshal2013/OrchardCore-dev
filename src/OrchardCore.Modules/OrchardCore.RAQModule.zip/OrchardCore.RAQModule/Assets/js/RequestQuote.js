document.getElementsByClassName("requestquoteButton").addEventListener("click", myFunction);

function myFunction() {
    var modal = document.getElementById("RequestQuoteModel");
    modal.style.display = "block";
}
   
